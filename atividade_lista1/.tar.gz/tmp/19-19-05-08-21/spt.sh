#!/bin/bash

data=`date +%H-%M--%d-%m-%y`

echo $data
